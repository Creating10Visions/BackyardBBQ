/*
Represents a backyard BBQ meal cooked on a grill.
*/
public class BackyardBBQ implements Meal_Cook {
// Type of grill used (charcoal or propane)
    private String grillType;

 // Constructor
    public BackyardBBQ(String grillType) {
        this.grillType = grillType;
}

// Getter 
    public String getGrillType() {
        return grillType;
}

// Setter 
    public void setGrillType(String grillType) {
        this.grillType = grillType;
}

// Implementation method from Meal_Cook interface
    @Override
    public String cook(String whatIsBeingCooked) {
        return whatIsBeingCooked + " cooked on a " + grillType + " grill for 10 minutes.";
    }

// toString method for printing object details
    @Override
    public String toString() {
        return "BackyardBBQ [grillType=" + grillType + "]";
    }
}