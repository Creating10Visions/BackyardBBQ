/*
It contains the main() method to run the program.
*/
public class CookingDinner {
    public static void main(String[] args) {
// Print course details
        System.out.println("Course: COP2805C");
        System.out.println("Assignment: P5");
        System.out.println("Date: 07/17/2024");
        System.out.println("Programmer: Vanessa Krug");

//objects of each type of dinner
        BackyardBBQ bbq = new BackyardBBQ("charcoal");
        ThanksgivingDinner thanksgiving = new ThanksgivingDinner("electric", "roasting pan");
        HeartyStew stew = new HeartyStew("crockpot");

 // Print details and cooking process for each dinner
        System.out.println(bbq);
        System.out.println(bbq.cook("Hamburgers"));

        System.out.println(thanksgiving);
        System.out.println(thanksgiving.cook("Turkey"));

        System.out.println(stew);
        System.out.println(stew.cook("Beef stew"));
    }
}