/*
Represents a hearty stew cooked in a crockpot or stovetop pot.
*/
public class HeartyStew implements Meal_Cook {
    private String potType; // Type of pot used (crockpot or stovetop)

// Constructor
    public HeartyStew(String potType) {
        this.potType = potType;
}

 // Getter 
    public String getPotType() {
        return potType;
 }

 // Setter 
    public void setPotType(String potType) {
        this.potType = potType;
}

 // Implementation cook method from Meal_Cook interface
    @Override
    public String cook(String whatIsBeingCooked) {
        return whatIsBeingCooked + " cooked in a " + potType + " for 8 hours.";
    }

 // toString method for printing object details
    @Override
    public String toString() {
        return "HeartyStew [potType=" + potType + "]";
    }
}