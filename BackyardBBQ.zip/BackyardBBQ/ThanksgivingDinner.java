/*
Represents a Thanksgiving dinner cooked in an oven using a roasting pan.
*/
public class ThanksgivingDinner implements Meal_Cook {
// Type of oven used
    private String ovenType; 
// Type of pan used 
    private String panType;  

// Constructor
    public ThanksgivingDinner(String ovenType, String panType) {
        this.ovenType = ovenType;
        this.panType = panType;
}

// Getter for oven type
    public String getOvenType() {
        return ovenType;
}

// Setter for oven type
    public void setOvenType(String ovenType) {
        this.ovenType = ovenType;
 }

// Getter for pan type
    public String getPanType() {
        return panType;
 }

// Setter for pan type
    public void setPanType(String panType) {
        this.panType = panType;
    }

// Implementation method from Meal_Cook interface
    @Override
    public String cook(String whatIsBeingCooked) {
        return whatIsBeingCooked + " cooked in an " + ovenType + " oven using a " + panType + " for 4 hours.";
    }

    // toString method for printing object details
    @Override
    public String toString() {
        return "ThanksgivingDinner [ovenType=" + ovenType + ", panType=" + panType + "]";
    }
}