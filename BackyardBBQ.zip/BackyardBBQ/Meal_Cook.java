/*
Meal_Cook.java
*/
public interface Meal_Cook {
 /* method cook() accepts a String of the meal being cooked
       returns a String with a message describing the cooking process
 */
    public abstract String cook(String whatIsBeingCooked);
}